const multer = require('multer');
const path = require('path');
const express = require('express');
const router = express.Router();

// Set up multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Specify the uploads folder
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Save file with a unique name
  },
});

const upload = multer({ storage });

// Service creation route
router.post('/api/services', upload.array('images', 5), async (req, res) => {
  const { name, category, description, price } = req.body;
  const images = req.files.map(file => file.path); // Get paths of uploaded images

  const newService = new Service({
    name,
    category,
    description,
    price,
    images, // Save image paths in database
  });

  try {
    await newService.save();
    res.status(201).json({ message: 'Service created successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error creating service', error });
  }
});
